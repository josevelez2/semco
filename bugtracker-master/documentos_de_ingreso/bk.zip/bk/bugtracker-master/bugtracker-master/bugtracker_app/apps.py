from django.apps import AppConfig


class BugtrackerAppConfig(AppConfig):
    name = 'bugtracker_app'
