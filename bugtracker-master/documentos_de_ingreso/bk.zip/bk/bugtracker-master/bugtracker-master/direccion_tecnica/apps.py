from django.apps import AppConfig


class DireccionTecnicaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'direccion_tecnica'
