from django.apps import AppConfig


class BugtrackerAreaghConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bugtracker_areaGH'